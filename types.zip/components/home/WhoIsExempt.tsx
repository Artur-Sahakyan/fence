import React from 'react';
import Title from "@/components/common/Title";
import Image from "next/image";

const WhoIsExempt = () => {

    const data = [
        {
            title: 'Non-Diesel Operated Vehicles',
            text: 'Zero-Emission Vehicles (ZEVs) that run on electric charge or vehicles that are fueled exclusively with gasoline do not have to obtain a Truck and Bus Certification.'
        },
        {
            title: 'Public Agency and Utility Vehicles (Non Federal)',
            text: 'Public agency and utility vehicles that are not federally owned and operated do not have to follow the Truck and Bus regulations as they have a separate emissions practice to follow using the Best Available Control Technology.'
        },
        {
            title: 'Transit/Urban Buses',
            text: 'CARB is working with California on separate incentives to reduce emissions for transit and urban buses, making them exempt from the truck and bus regulations.'
        },
        {
            title: 'Personal Use Motor Homes/Recreational Vehicles (RVs)',
            text: 'Even if a personal use motor home/recreational vehicle meets the weight requirements, it is exempt from the truck and bus regulations as they do not have to follow the same permitting protocols as commercial vehicles.'
        },
        {
            title: 'Emergency Vehicles:',
            text: 'Vehicles such as ambulances and fire trucks that operate solely for emergency services are exempt from truck and bus regulations.'
        },

    ]

    return (
        <div className='bg-white pt-4 pb-9 px-9 rounded-2xl shadow-compliance scrollTopMargin xl:px-3 xl:pb-3' id='who-is-exempt'>
            <Title>Who Is Exempt?</Title>
            <p className='text-xl text-center font-medium mb-7 xl:text-xl xl:text-center md:text-sm'>Like every permit, there are a few exceptions to the rule that leave
                some vehicles exempt from requiring a Truck and Bus Regulation Certificate. The following vehicle types
                are exempt.</p>
            <div className='grid grid-cols-2 gap-11 xl:grid-cols-1 xl:gap-4'>
                <div className='flex flex-col gap-5'>
                    {data.map((item, idx) => (
                        <p key={idx} className='text-xl md:text-sm xl:flex xl:flex-col xl:items-center xl:text-center xl:gap-2'>
                            <strong className='mr-2 md:mr-0 md:text-base'>{item.title}<span className='xl:hidden'>:</span></strong>
                            {item.text}
                        </p>
                    ))}

                </div>
                <div className='relative h-full xl:min-h-[400px] xl:rounded-lg md:min-h-40'>
                    <Image src='/images/exempt.png' alt='Who Is Exempt' fill className='object-contain xl:rounded-lg xl:object-cover'/>

                </div>
            </div>
        </div>
    );
};

export default WhoIsExempt;