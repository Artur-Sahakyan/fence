import React from 'react';
import Title from "@/components/common/Title";
import IconService1 from "@/components/icons/IconService1";
import IconService2 from "@/components/icons/IconService2";
import IconService3 from "@/components/icons/IconService3";

const Services = () => {

    const services = [
        {
            icon: <IconService1 />,
            text: 'Assistance and guidance through the Truck Regulations, Upload, and Compliance Reporting System.'
        },
        {
            icon: <IconService2 />,
            text: 'Fast and secure submission process to ensure emissions compliance with the DMV.'
        },
        {
            icon: <IconService3 />,
            text: 'Confirmation of compliance status sent straight to you.'
        }
    ]

    return (
        <div>
            <Title>Our Services</Title>
            <p className='text-[28px] mb-7 xl:text-xl xl:text-center md:text-sm'>Truck & Bus Regulation Reporting assists clients in obtaining their Truck and Bus Certificate.</p>
            <div className='grid grid-cols-3 gap-8 xl:gap-3 md:[&_svg]:w-12 md:grid-cols-1'>
                {services.map((item, idx) => (
                    <div key={idx} className='shadow-service rounded-3xl p-4 bg-white text-black text-2xl xl:text-lg md:text-sm'>
                        {item.icon}
                        <p className='mt-7'>{item.text}</p>
                    </div>
                ))}

            </div>
        </div>
    );
};

export default Services;