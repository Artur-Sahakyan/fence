import React from 'react';
import Title from "@/components/common/Title";
import {VEHICLE_PRICE} from "@/utils/constants";
import Button from "@/components/common/Button";
import Link from "next/link";

const Pricing = () => {

    const list = [
        'Complete regulation reporting for trucks and buses',
        'Timely and accurate filing',
        'Expert assistance to ensure full compliance'
    ]

    return (
        <div className='bg-white p-[68px] rounded-2xl shadow-engine scrollTopMargin xxl:p-3' id='pricing'>
            <div className='flex gap-8 px-2 xl:flex-col xl:gap-3'>
                <div>
                    <Title className='text-start md:!mb-2'>Pricing</Title>
                    <p className='text-[70px] text-black font-bold xl:text-4xl'>${VEHICLE_PRICE} <span
                         className='text-primary text-3xl xl:text-xl'>per vehicle</span></p>

                </div>
                <div>
                    <h3 className='text-[26px] font-semibold text-black mb-6 md:text-sm'>${VEHICLE_PRICE} per vehicle — no surprise
                        charges, no extra fees</h3>
                    <ul className='list-disc pl-10 text-[#717680] text-[22px] font-medium md:text-xs'>
                        {list.map((item, idx) => (
                            <li key={idx}>{item}</li>
                        ))}
                    </ul>
                </div>
            </div>
            <Link href='/form' className='flex justify-center w-full mt-12 xl:mt-6'>
                <Button className='contained w-full max-w-[600px] !text-2xl !h-[65px] !rounded-[14px] xxl:!h-12 xxl:!text-lg' aria-label='Apply Now for Your Certificate'>Get Started Today</Button>
            </Link>
        </div>
    );
};

export default Pricing;