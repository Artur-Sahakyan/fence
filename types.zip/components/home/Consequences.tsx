import React from 'react';
import Title from "@/components/common/Title";
import Image from "next/image";

const Consequences = () => {

    const data = [
        {
            title: 'DMV Registration Holds or Denials',
            text: 'If you fail to comply with Truck and Bus regulations, the California Department of Motor Vehicles could withhold or deny registrations. This could prevent the vehicle from operating.',
            image: 'cons-1.png'
        },
        {
            title: 'Operational Disruptions:',
            text: 'If a qualifying vehicle is found to be non-compliant, actions could be taken against it that would interfere with business operations. These actions include out-of-service orders or increased roadside checks.',
            image: 'cons-2.png'
        },
        {
            title: 'Fines and Penalties:',
            text: 'Depending on the case of non-compliance, registered vehicle owners could face financial penalties in the form of fines. The fines can add up with a per-vehicle, per-day basis for each day a vehicle(s) is found to be non-compliant.',
            image: 'cons-3.png'
        },
        {
            title: 'Legal Action',
            text: 'Vehicles that are repeatedly found to be non-compliant could face legal action. This includes liens being placed on the vehicle and could potentially lead to criminal charges as well.',
            image: 'cons-4.png'
        }
    ]

    return (
        <div className='bg-white pt-4 pb-9 px-9 rounded-2xl shadow-compliance scrollTopMargin 3xl:!p-3' id='consequences'>
            <Title>Consequences of Non-Compliance</Title>
            <p className='text-xl text-center font-medium mb-12 xl:text-xl xl:mb-7 xl:text-center md:text-sm'>If you operate a qualifying vehicle on public California roads and
                are found to operate outside of the Truck and Bus regulations or have not properly registered your
                vehicle, you could face significant consequences.</p>
            <div className='grid grid-cols-2 gap-x-11 gap-y-6 3xl:gap-x-6 xl:grid-cols-1 xl:gap-3'>
                {data.map((item, idx) => (
                    <div key={idx} className='grid grid-cols-2 gap-8 p-3 3xl:gap-5 md:grid-cols-1 md:p-0'>
                        <div className='relative xl:min-h-[234px] md:order-2'>
                            <Image src={`/images/${item.image}`} alt={item.title} fill className='object-cover rounded-2xl md:object-bottom' />
                        </div>
                        <div className='flex flex-col gap-2 md:order-1 md:gap-[6px]'>
                            <h3 className='text-lg font-bold min-h-14 xl:min-h-max'>{item.title}</h3>
                            <p className='md:text-sm'>{item.text}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Consequences;