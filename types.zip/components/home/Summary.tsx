import React from 'react';
import IconSummary1 from "@/components/icons/IconSummary1";
import IconSummary2 from "@/components/icons/IconSummary2";
import IconSummary4 from "@/components/icons/IconSummary4";
import IconSummary3 from "@/components/icons/IconSummary3";
import Title from "@/components/common/Title";
import Image from "next/image";

const Summary = () => {

    const data = [
        {
            title: 'Truck and Bus Regulation Certificate',
            text: 'In order to show your compliance with the truck and bus regulations, after all information is verified and your vehicle has been tested, you receive a certificate allowing you to operate legally on California public roads.',
            icon: <IconSummary1/>
        },
        {
            title: 'Requirements',
            text: 'All heavy-duty diesel fueled vehicles (with a GVWR of 14,000 pounds or more) must follow the Truck and Bus regulations and report their vehicle information in the TRUCRS. These vehicles must have an engine no older than from 2010.',
            icon: <IconSummary2/>
        },
        {
            title: 'Exemptions',
            text: 'Vehicles that operate on non-diesel power (regular gasoline or electric) do not have to report to the TRUCRS. Emergency vehicles, public agency/utility vehicles that are non-federally operated, and personal use motor homes/RVs are also exempt.',
            icon: <IconSummary3/>
        },
        {
            title: 'Consequences of Non-Compliance',
            text: 'If vehicles are found to be non-compliant with the Truck and Bus regulations set forth by the California Air Resources Board, they could face fines, registration issues, operational disruptions, and even legal action.',
            icon: <IconSummary4/>
        },
    ]

    return (
        <div className='bg-white p-6 pb-9 rounded-2xl shadow-compliance flex gap-7 xl:!p-3'>
            <div>
                <Title className='text-start md:text-center'>Summary</Title>
                <div className='flex flex-col gap-10 mt-12 md:gap-3'>
                    {data.map((item, idx) => (
                        <div key={idx} className='flex items-center gap-4 sm:flex-col'>
                            <div className='w-[66px] h-[66px] min-w-[66px] rounded-lg bg-primary flex items-center justify-center'>
                                {item.icon}
                            </div>
                            <div className='sm:text-center'>
                                <h3 className='text-xl font-semibold mb-3 md:text-lg'>{item.title}</h3>
                                <p className='text-sm'>{item.text}</p>
                            </div>
                        </div>
                    ))}

                </div>
            </div>
            <div className='relative w-full xl:hidden'>
                <Image src='/images/summary.png' alt='Summary' fill className='object-cover rounded-2xl' />
            </div>
        </div>
    );
};

export default Summary;