'use client';
import React, {useState} from 'react';
import Title from "@/components/common/Title";
import IconAcc from "@/components/icons/IconAcc";

const Faq = () => {
    const faqData = [
        {
            question: 'What does the registration process look like?',
            answer: 'To start, you provide us with your required vehicle information, such as your VIN number, engine year, etc; and we register you in the TRUCRS. We set your vehicle up for the necessary testing. Then, as long as your vehicle passes the tests, you will receive your certification from us!'
        },
        {
            question: 'What kind of testing does my vehicle go through?',
            answer: 'There are two different test types: i. OBD-equipped vehicles (2013 and newer diesel engines or 2018 and newer alternative fuel engines) undergo a scan of the engine’s OBD data. This is done by a CARB certified OBD testing device. ii. Diesel non-OBD vehicles (engines from 2012 or older) must complete a smoke opacity test and visual inspection of the vehicle’s emissions control equipment.'
        },
        {
            question: 'What does OBD mean?',
            answer: 'OBD stands for on-board diagnostics.'
        },
        {
            question: 'What should I do if my engine is from before 2010?',
            answer: 'If you have a vehicle that qualifies for the Truck and Bus regulations but your engine is from before 2010, you will need to get a newer engine. If you do not, you will be considered non-compliant and could face interruptions in your registration process and business operations.'
        },
        {
            question: 'Do I need to be registered with TRUCRS if I do not operate in California?',
            answer: 'If your vehicle meets the requirements for the truck and bus regulations but your vehicle is neither registered in the state of California nor do you ever operate on California public roads, then you do not need a Truck and Bus regulation certificate.'
        },
        {
            question: 'Do I need to be registered with TRUCRS if I am not registered in California, but I do operate in California?',
            answer: 'Even if your business is based in a different state, if you operate on public California roads, you have to follow the Truck and Bus regulations set by CARB.'
        }
    ]

    const [openIndex, setOpenIndex] = useState<null | number>(null);

    const toggleAccordion = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    return (
        <div className='bg-white pt-4 pb-9 px-9 rounded-2xl shadow-compliance scrollTopMargin xl:!p-3' id='faq'>
            {/*<Title>Frequently Asked Questions <br/> (FAQs)</Title>*/}
            <Title className='!mb-0'>Frequently Asked Questions</Title>
            <Title>(FAQs)</Title>

            {faqData.map((faq, index) => (
                <div key={index} className="border-b py-3 px-6 xl:p-3">
                    <div
                        className="flex justify-between items-center gap-2 cursor-pointer md:text-sm"
                        onClick={() => toggleAccordion(index)}
                    >
                        <span className="font-semibold text-[21px] xxl:text-base md:text-sm">{faq.question}</span>
                        <IconAcc className={`transform transition-transform duration-200 min-w-10 md:!w-8 md:!h-8 md:!min-w-8 ${openIndex === index ? 'rotate-180' : ''}`} />
                    </div>
                    <div
                        className={`overflow-hidden transition-all duration-500 ease-in-out transform ${openIndex === index ? 'scale-y-100 opacity-100' : 'scale-y-0 opacity-0 h-0'}`}
                    >
                        <p className="text-gray-700 px-4 pt-2 md:text-sm md:px-2">{faq.answer}</p>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default Faq;