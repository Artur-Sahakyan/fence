import React from 'react';
import IconNeeds1 from "@/components/icons/IconNeeds1";
import IconNeeds2 from "@/components/icons/IconNeeds2";
import IconNeeds3 from "@/components/icons/IconNeeds3";
import Title from "@/components/common/Title";

const WhoNeeds = () => {

    const data = [
        {
            title: 'Heavy-Duty Diesel Vehicles',
            text: 'Heavy-duty diesel vehicles, largely trucks and buses, in general must follow the truck and bus regulation standards. The vehicles qualify as heavy-duty if they have a gross vehicle weight over 14,000 pounds.',
            icon: <IconNeeds1 />
        },
        {
            title: 'California Heavy-Duty Vehicles',
            text: 'All heavy-duty vehicles that are registered in California and meet the weight qualification requirements must file with the TRUCRS.',
            icon: <IconNeeds2 />
        },
        {
            title: 'Out-of-State Qualifying Vehicles',
            text: 'If you own a heavy-duty vehicle that is registered outside of California, but you operate on California public roads and meet the weight qualification requirements, you must file with the TRUCRS.',
            icon: <IconNeeds3 />
        }
    ]

    return (
        <div className='bg-white pt-4 px-9 pb-14 rounded-2xl shadow-need-apply md:px-3 md:pb-3 scrollTopMargin'>
            <Title>Who Needs to Apply for a Truck and Bus Regulation Certificate?</Title>
            <div className='grid grid-cols-3 gap-6 mt-[67px] xl:grid-cols-2 xl:gap-4 xl:mt-0 md:grid-cols-1 md:[&_svg]:scale-90'>
                {data.map((item, idx) => (
                    <div key={idx}
                         className={`rounded-2xl p-4 border border-[#BEBEBE] bg-white text-black`}>
                        <div className='h-[92px]'>
                            {item.icon}
                        </div>
                        <h3 className='text-2xl font-bold min-h-14 mt-4 mb-8 md:text-base md:my-3 md:min-h-max'>{item.title}</h3>
                        <p className='font-medium md:text-sm'>{item.text}</p>
                    </div>
                ))}

            </div>
        </div>
    );
};

export default WhoNeeds;