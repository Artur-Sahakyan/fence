import React from 'react';
import Title from "@/components/common/Title";
import Image from "next/image";

const Emissions = () => {

    const data = [
        {
            text: 'OBD-equipped vehicles (vehicles with diesel engines from 2013 or newer OR 2018 and newer alternative fuel engines) must undergo scan tests of the engine’s OBD data. This is done with a CARB certified OBD testing device.',
            image: 'emission-1.png'
        },
        {
            text: 'Diesel non-OBD vehicles (vehicles with diesel engines from 2012 or older) must complete smoke opacity testing, as well as a visual inspection of the vehicle’s emissions control equipment. This is known as the Vehicle Emissions Control Equipment Inspection. Alternative fuel non-OBD vehicles (alternative fuel engines from 2017 or older) undergo only the visual inspection.',
            image: 'emission-2.png'
        }
    ]

    return (
        <div className='bg-white py-4 px-16 rounded-2xl shadow-compliance xxl:px-4'>
            <Title>Emissions Tests</Title>
            <p className='text-xl text-center font-medium mb-7 xl:text-xl xl:text-center md:text-sm'>After reporting your vehicle information, in order to verify your
                vehicle meets emission standards, your vehicle must undergo emission testing.</p>
            <div className='grid grid-cols-2 gap-11 min-h-[615px] xl:gap-4 lg:grid-cols-1 lg:min-h-max'>
                {data.map((item, idx) => (
                    <div key={idx} className='p-4 rounded-2xl border border-[#DCDCDC] flex flex-col gap-5 md:gap-3'>
                        <p className='text-xl font-medium lg:text-lg md:text-sm'>{item.text}</p>
                        <div className='relative h-full lg:min-h-[215px]'>
                            <Image src={`/images/${item.image}`} alt='Emissions Test' fill
                                   className='object-contain rounded-2xl'/>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Emissions;