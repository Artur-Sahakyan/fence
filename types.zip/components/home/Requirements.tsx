import React from 'react';
import IconReq1 from "@/components/icons/IconReq1";
import IconReq2 from "@/components/icons/IconReq2";
import IconReq3 from "@/components/icons/IconReq3";
import IconReq4 from "@/components/icons/IconReq4";
import Title from "@/components/common/Title";

const Requirements = () => {

    const requirements = [
        {
            title: 'Gross Vehicle Weight Rating (GVWR)',
            text: 'As a general rule, Truck and Bus certificates are for heavy-duty vehicles that have a GVWR of over 14,000 pounds. The emission standards in the regulation are specific to vehicles of this size.',
            icon: <IconReq1 />
        },
        {
            title: 'Engine Model Year Requirement',
            text: 'Per CARB, your vehicle must have an engine that is no older than from 2010. Engines built before 2010 do not meet the emission standards set by CARB and are not permitted to be used in operating heavy-duty vehicles.',
            icon: <IconReq2 />
        },
        {
            title: 'Report Via TRUCRS',
            text: 'In order to actually obtain the certificate, the vehicle owner must register the vehicle in the Truck Regulations, Upload, and Compliance Reporting System and report vehicle information such as VIN number, weight, and engine type and age.',
            icon: <IconReq3 />
        },
        {
            title: 'Maintenance of Emission Standards',
            text: 'In order to keep an active and valid Truck and Bus Certificate, the vehicle must maintain its following of emission standards. If something changes in the vehicle that affect its emissions, it must be updated in the TRUCRS.',
            icon: <IconReq4 />
        }
    ]

    return (
        <div className='bg-white p-4 pb-8 rounded-2xl shadow-section scrollTopMargin' id='get-certified'>
            <Title>Requirements to Obtain the Certificate</Title>
            <p className='text-xl text-center font-medium mb-7 xl:text-xl xl:text-center md:text-sm'>In order to obtain your Truck and Bus Certificate, you must meet certain requirements established by the California Air Resources Board.</p>
            <div className='grid grid-cols-4 gap-5 xl:grid-cols-2 md:grid-cols-1 lg:[&_svg]:max-h-[68px]'>
                {requirements.map((item, idx) => (
                    <div key={idx} className={`rounded-2xl shadow-req p-3 ${idx%2 ? 'bg-primary text-white' : 'border border-[#BEBEBE] bg-white text-black'}`}>
                        {item.icon}
                        <h3 className='text-xl font-bold min-h-14 my-8 xl:my-3 md:min-h-max md:text-base'>{item.title}</h3>
                        <p className='font-medium md:text-sm'>{item.text}</p>
                    </div>
                ))}

            </div>
        </div>
    );
};

export default Requirements;