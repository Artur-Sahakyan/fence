import React from 'react';
import Title from "@/components/common/Title";
import Image from "next/image";

const EngineYear = () => {

    return (
        <div className='bg-white p-4 rounded-2xl shadow-engine'>
            <Title>Why Does Engine Year Matter?</Title>
            <div className='grid grid-cols-2 gap-12 px-[72px] mt-7 lg:grid-cols-1 lg:px-4'>
                <p className='text-2xl font-medium lg:text-lg lg:text-center md:text-sm'>
                    Per the California Air Resources Board, the engine year is important as emission standards have
                    changed over time. This means that as time has gone on, automakers have been required to adjust
                    their engines to comply with emission standards in order to reduce toxic emissions. Engines built in
                    2010 or more recently are equipped with advanced emissions control systems that reduce particulate
                    matter (PM) and nitrogen oxides (NOX).
                </p>
                <div className='relative min-h-[430px] lg:hidden'>
                    <Image src='/images/engine.png' alt='Engine' fill className='object-contain'/>
                </div>
            </div>
        </div>
    );
};

export default EngineYear;