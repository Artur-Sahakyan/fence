import React, {useState} from 'react';
import {Control, Controller, FieldValues, UseFormSetValue} from "react-hook-form";

type Props = {
    initialsArr: {value: string}[],
    setValue: UseFormSetValue<FieldValues>,
    control: Control<FieldValues>;
}

const TermsSection = ({initialsArr, setValue, control}: Props) => {
    const [termIdx, setTermIdx] = useState<number | null>(null);
    const termsData = [
        'I certify that I am the authorized holder and signer of the credit card referenced above. I certify that all the information above is complete and accurate.',
        'I understand that the information input is correct to my knowledge. Submitting false information could result in penalties and fines. It is a federal crime to submit false information in an attempt to commit fraud.',
        'I hereby authorize the collection of payment to DOT Operating Authority Inc., (DBA) Truck and Bus Regulation Reporting, for all charges as indicated above. I acknowledge that charges to my provided payment method may not exceed the total amount listed under the “TOTAL PRICE” field. I understand that I am responsible for the full amount listed in the “TOTAL PRICE” field. I understand that this authorization is only in effect during the time period of this transaction. If any additional charges are to need authorization, a new authorization form will have to be completed.',
        'I acknowledge that the total amount of today’s transaction, indicated under the “TOTAL PRICE” field includes any and all Federal, State, and Local Government fees.',
        'I hereby acknowledge and agree that after the charges are authorized, a DOT Operating Authority Inc., (DBA) Truck and Bus Regulation Reporting agent will be assigned within 15 minutes to complete the order. Once the agent has been assigned, the payment cannot be cancelled, and the charges are non-refundable. DOT Operating Authority Inc., (DBA) Truck and Bus Regulation Reporting does not accept any responsibility for refusal or reversal of payments, which shall be a matter between you and your credit card issuer.'
    ];

    function onInitialsValueChange (e: React.ChangeEvent<HTMLInputElement>, idx: number) {
        const { value } = e.target;
        const upperValue = value?.toUpperCase();
        const initialsArray = initialsArr;
        const isFillFirstTime = initialsArray?.every((item) => !item.value || item.value.length === 1);

        if (isFillFirstTime) {
            initialsArray.forEach((_, index) => {
                setValue(`initials.${index}.value`, upperValue);
            });
        } else {
            setValue(`initials.${idx}.value`, upperValue);
        }
    };

    return (
        <>
        {termsData.map((term, idx) => (
                <div key={idx} className='flex items-start gap-2'>
                    <div className='form_block input_block !w-fit [&_input]:placeholder:!text-xs'>
                        <Controller
                            name={`initials.${idx}.value`}
                            control={control}
                            defaultValue=""
                            render={({field}) => (
                                <input
                                    {...field}
                                    type='text'
                                    autoComplete='off'
                                    placeholder='Initials'
                                    maxLength={2}
                                    onChange={(e)=>{onInitialsValueChange(e, idx)}}
                                    className={`!w-[50px] !h-9 !p-[2px] text-center`}
                                />
                            )}
                        />
                    </div>
                    <ul className='color-p'>
                        <li onClick={() => setTermIdx(termIdx === idx ? null : idx)}
                            className={termIdx === idx ? 'active' : ''}>
                            <div className='flex items-center gap-1 container'>
											<span
                                                className={`text ${termIdx === idx ? 'md:line-clamp-0' : 'md:line-clamp-2'}`}>{term}</span>
                                <span className={`hidden arrow md:block ${termIdx === idx ? 'rotate-180' : ''}`}>▼</span>
                            </div>
                        </li>
                    </ul>
                </div>
            ))}
        </>
    );
};

export default TermsSection;