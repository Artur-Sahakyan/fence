
export const contactInfo = {
    email: 'service@truckandbusregulation.com',
    phone: '(800) 253-1796',
    address: '1906 W Burbank Blvd, Burbank, CA 91506'
};