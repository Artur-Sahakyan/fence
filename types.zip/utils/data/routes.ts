
export const headerRoutes = [
    {title: 'Regulation', href: '/#regulation'},
    {title: 'How to Apply', href: '/#how-to-apply'},
    {title: 'Get Certified', href: '/#get-certified'},
    {title: 'Pricing', href: '/#pricing'},
    {title: 'Who Is Exempt', href: '/#who-is-exempt'},
    {title: 'Consequences', href: '/#consequences'},
    {title: 'FAQ', href: '/#faq'},
    {title: 'Contact Us', href: '/#contact-us'},
];