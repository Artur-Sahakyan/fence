"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/use-isomorphic-layout-effec_de4ec1a85c7d5a5ac4f4da54aac10624";
exports.ids = ["vendor-chunks/use-isomorphic-layout-effec_de4ec1a85c7d5a5ac4f4da54aac10624"];
exports.modules = {

/***/ "(ssr)/./node_modules/.pnpm/use-isomorphic-layout-effec_de4ec1a85c7d5a5ac4f4da54aac10624/node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.esm.js":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/use-isomorphic-layout-effec_de4ec1a85c7d5a5ac4f4da54aac10624/node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.esm.js ***!
  \****************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ index)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"(ssr)/./node_modules/.pnpm/next@15.1.7_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\n\nvar isClient = typeof document !== 'undefined';\n\nvar index = isClient ? react__WEBPACK_IMPORTED_MODULE_0__.useLayoutEffect : react__WEBPACK_IMPORTED_MODULE_0__.useEffect;\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvLnBucG0vdXNlLWlzb21vcnBoaWMtbGF5b3V0LWVmZmVjX2RlNGVjMWE4NWM3ZDVhNWFjNGY0ZGE1NGFhYzEwNjI0L25vZGVfbW9kdWxlcy91c2UtaXNvbW9ycGhpYy1sYXlvdXQtZWZmZWN0L2Rpc3QvdXNlLWlzb21vcnBoaWMtbGF5b3V0LWVmZmVjdC5lc20uanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQW1EOztBQUVuRDs7QUFFQSx1QkFBdUIsa0RBQWUsR0FBRyw0Q0FBUzs7QUFFdEIiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcbWFya2VcXE9uZURyaXZlXFxEZXNrdG9wXFxQcm9qZWN0c1xcdlxcbm9kZV9tb2R1bGVzXFwucG5wbVxcdXNlLWlzb21vcnBoaWMtbGF5b3V0LWVmZmVjX2RlNGVjMWE4NWM3ZDVhNWFjNGY0ZGE1NGFhYzEwNjI0XFxub2RlX21vZHVsZXNcXHVzZS1pc29tb3JwaGljLWxheW91dC1lZmZlY3RcXGRpc3RcXHVzZS1pc29tb3JwaGljLWxheW91dC1lZmZlY3QuZXNtLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUxheW91dEVmZmVjdCwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuXG52YXIgaXNDbGllbnQgPSB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG52YXIgaW5kZXggPSBpc0NsaWVudCA/IHVzZUxheW91dEVmZmVjdCA6IHVzZUVmZmVjdDtcblxuZXhwb3J0IHsgaW5kZXggYXMgZGVmYXVsdCB9O1xuIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6WzBdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/.pnpm/use-isomorphic-layout-effec_de4ec1a85c7d5a5ac4f4da54aac10624/node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.esm.js\n");

/***/ })

};
;