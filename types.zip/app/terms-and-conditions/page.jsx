import React from 'react';
import TermsBlock from "@/components/terms/TermsBlock";

const TermsAndConditions = () => {

	const data = [
		{
			desc: 'These terms and conditions govern the use of truckandbusregulation.com. This site is owned and operated by DOT Operating Authority Inc., DBA Truck and Bus Regulation Reporting. This site is an e-commerce website.',
		},
		{
			desc: 'By using this site, you indicate that you have read and understand these terms and conditions and agree to abide by them at all times.'
		},
		{
			title: 'Intellectual Property',
			desc: 'All content published and made available on our site is the property of DOT Operating Authority Inc., DBA Truck and Bus Regulation Reporting and the site’s creators. This includes, but is not limited to images, text, logos, documents, downloadable files, and anything that contributes to the composition of our site.'
		},
		{
			title: 'Acceptable Use',
			desc: 'As a user of our site, you agree to use our site legally, not to use our site for illegal purposes, and not to:',
			list: [
				'Harass or mistreat other users of our site;',
				'Violate the rights of other users of our site; or',
				'Act in any way that could be considered fraudulent.'
			],
			short_desc: 'If we believe you are using our site illegally or in a manner that violates these terms and conditions, we reserve the right to limit, suspend, or terminate your access to our site. We also reserve the right to take any legal steps necessary to prevent you from accessing our site.'
		},
		{
			title: 'Accounts',
			desc: 'When you register your information on our site, you agree to the following:',
			list: [
				'You are solely responsible for your account and the security and privacy of your account, including passwords or sensitive information attached to that account; and',
				'All personal information you provide to us through your account is up-to-date, accurate, and truthful and you will update your personal information if it changes.'
			],
			numberList: true,
			short_desc: 'We reserve the right to suspend or terminate your account if you are using our site illegally or if you violate these terms and conditions.'
		},
		{
			title: 'Sales of Services',
			desc: 'These terms and conditions govern the sale of services available on our site.'
		},
		{
			desc: 'The following services are available on our site:',
			list: [
				'Filing Submission',
				'Registration Updates'
			],
			short_desc: 'The services will be paid for in full when the services are ordered.'
		},
		{
			desc: 'These terms and conditions apply to all the services that are displayed on our site at the time you access it. All information, descriptions, or images that we provide about our services are as accurate as possible. However, we are not legally bound by such information, descriptions, or images, as we cannot guarantee the accuracy of all services we provide. You agree to purchase services from our site at your own risk.'
		},
		{
			desc: 'We reserve the right to modify, reject, or cancel your order whenever it becomes necessary. If we cancel your order and have already processed your payment, we will give you a refund equal to the amount you paid. You agree that it is your responsibility to monitor your payment instrument to verify receipt of any refund.'
		},
		{
			title: 'Payments',
			desc: 'We accept the following payment methods on our site:',
			list: [
				'Credit Card',
				'Debit Card'
			],
			short_desc: 'When you provide us with your payment information, you authorize our use of and access to the payment instrument you have chosen to use. By providing us with your payment information, you authorize us to charge the amount due to this payment instrument.'
		},
		{
			desc: 'If we believe your payment has violated any law or these terms and conditions, we reserve the right to cancel or reverse your transaction.'
		},
		{
			title: 'Cancellation and Refund Policy',
			desc: 'An order cannot be cancelled and refunded once it has been assigned to one of our agents during our business hours. Once the order has been processed and assigned to an agent, you are ineligible for a cancellation and/or refund.'
		},
		{
			title: 'Consumer Protection Law',
			desc: 'Where any consumer protection legislation in your jurisdiction applies and cannot be excluded, these terms and conditions will not limit your legal rights and remedies under that legislation. These terms and conditions will be read subject to the mandatory provisions of that legislation. If there is a conflict between these terms and conditions, the mandatory provisions of the legislation will apply.'
		},
		{
			title: 'Limitation of Liability',
			desc: 'DOT Operating Authority Inc., DBA Truck and Bus Regulation Reporting and our directors, officers, agents, employees, subsidiaries, and affiliates will not be liable for any actions, claims, losses, damages, liabilities, and expenses including legal fees from your use of the site.'
		},
		{
			title: 'Indemnity',
			desc: 'Except where prohibited by law, by using this site you indemnify and hold harmless DOT Operating Authority Inc., DBA Truck and Bus Regulation Reporting and our directors, officers, agents, employees, subsidiaries, and affiliates from any actions, claims, losses, damages, liabilities, and expenses including legal fees arising out of your use of our site or your violation of these terms and conditions.'
		},
		{
			title: 'Applicable Law',
			desc: 'These terms and conditions are governed by the laws of the state of California.'
		},
		{
			title: 'Severability',
			desc: 'If at any time any of the provisions set forth in these terms and conditions are found to be inconsistent or invalid under applicable laws, those provisions will be deemed void and will be removed from these terms and conditions. All other provisions will not be affected by the removal and the rest of these terms and conditions will still be considered valid.'
		},
		{
			title: 'Changes',
			desc: 'These terms and conditions may be amended from time to time in order to maintain compliance with the law and to reflect any changes to the way we operate our site and the way we expect users to behave on our site. We will post a notice on our site if any change occurs to our terms and conditions.'
		}
	]

	return (
		<TermsBlock data={data} title='Terms And Conditions' type='terms' />
	);
};

export default TermsAndConditions;