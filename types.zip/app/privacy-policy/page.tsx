import React from 'react';
import TermsBlock from "@/components/terms/TermsBlock";

const PrivacyPolicy = () => {

    const data = [
        {
            desc: 'DOT Operating Authority Inc., DBA Truck and Bus Regulation Reporting operates under truckandbusregulation.com, which provides the service of filing for the Truck and Bus Regulation Certification for our customers.',
        },
        {
            desc: 'This page is to inform visitors to our website of the policies regarding the collection, use, and disclosure of personal information, should one use our service via our website.'
        },
        {
            desc: 'If you choose to file with DOT Operating Authority Inc., DBA Truck and Bus Regulation Reporting, you agree to the collection and use of information in relation to this policy. The personal information we collect is used for providing and improving our service. We will not share or use your information with anyone, except as explained in this privacy policy.'
        },
        {
            title: 'Collection and Use of Information',
            desc: 'In order to have a better experience with using DOT Operating Authority Inc., DBA Truck and Bus Regulation Reporting, we may ask you to provide certain personal information, such as your name, phone number, email address, and more. This information will be used to contact and/or identify you.'
        },
        {
            title: 'Log Data',
            desc: 'When you visit our website, we collect information known as Log Data from your browser. This information can include your Internet Protocol (aka IP) address, browser version, what pages of our website you visit, when you visit our website, how long you spend on each page, and other collected statistical information.'
        },
        {
            title: 'Cookies',
            desc: 'Cookies are files that hold a small amount of data used most commonly to create an identity of anonymity. Your browser sends these from the websites you visit and then stores this information on your computer’s hard drive. This information is used by DOT Operating Authority Inc., DBA Truck and Bus Regulation Reporting as a means to collect information in order to improve our services. You can accept or reject these and are able to know when a cookie is sent to your computer. If you opt to reject our website’s cookies, you may lose access to some parts of what we offer.'
        },
        {
            title: 'Service Providers',
            desc: 'There are a few instances in which we may employ third-party companies. These instances are as follows:',
            list: [
                'To better facilitate our service;',
                'To have the service provided on our behalf;',
                'To perform other services related to our service,',
                'To analyze how our service is used.'
            ],
            short_desc: 'These third parties may have access to your personal information in order for them to best complete the services assigned by us to them. They are obligated to follow our privacy policy and are not to disclose or use any information obtained for any purpose other than the intended service.'
        },
        {
            title: 'Cancellation and Refund Policy',
            desc: 'An order cannot be cancelled and refunded once it has been assigned to one of our agents during our business hours. Once the order has been processed and assigned to an agent, you are ineligible for a cancellation and/or refund.'
        },
        {
            title: 'Information Protection',
            desc: 'We honor your trust in providing personal information to us. However, due to the nature of the information being collected, we cannot guarantee the 100% safe protection of your information, as transmission over the internet is never 100% secure.'
        },
        {
            title: 'Changes to Our Privacy Policy',
            desc: 'Occasionally, we may need to update this privacy policy. When any changes are made, this web page will be updated and effective immediately.'
        },
    ]


    return (
        <TermsBlock data={data} title='Privacy Policy'/>
    );
}
;

export default PrivacyPolicy;